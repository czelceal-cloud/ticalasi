let mediaRecorder = null;
let recordedChunks = [];
let isScrolling = false;
let scrollAnimationFrame = null;
let frameCount = 0;
let lastCheckPosition = -1;
let lastDOMStateHash = "";
let unchangedCount = 0;
let isLoadingWait = false;

const SAMPLE_INTERVAL = 15;
const WARMUP_FRAMES = 90;
const MAX_UNCHANGED_STRIKES = 6;

function findTrueScrollContainer() {
  const selectors = [
    '[class*="chat" i][class*="scroll" i]',
    '[class*="message" i]',
    '.chat-discussion',
    'main'
  ];
  for (let selector of selectors) {
    const el = document.querySelector(selector);
    if (el && el.scrollHeight > el.clientHeight && el.clientHeight > 300) return el;
  }
  const allDivs = document.querySelectorAll('div');
  for (let div of allDivs) {
    const rect = div.getBoundingClientRect();
    if (
      div.scrollHeight > div.clientHeight &&
      rect.height > 300 &&
      rect.width > 400 &&
      window.getComputedStyle(div).overflowY !== 'hidden'
    ) {
      return div;
    }
  }
  return document.documentElement;
}

function getDOMStateHash(container) {
  const endSign = container.querySelector(
    '[class*="no-more" i], [class*="end" i], [class*="bottom-line" i]'
  );
  if (endSign && endSign.getBoundingClientRect().top > 0) {
    return "DEAD_END";
  }
  const firstChild = container.firstElementChild;
  const transform = firstChild ? firstChild.style.transform : "";
  const childCount = container.children.length;
  return `${childCount}_${transform}_${container.scrollHeight}`;
}

function isElementLoading(container) {
  const loadingEl = container.querySelector(
    '[class*="loading" i], [class*="spin" i], [class*="skeleton" i], [role="status"], svg[class*="load" i]'
  );
  return !!loadingEl;
}

function scrollLoop(container, pixelsPerFrame) {
  if (!isScrolling) return;
  frameCount++;

  if (isElementLoading(container)) {
    if (!isLoadingWait) {
      printLog("检测到懒加载组件，原地等待 DOM 渲染...");
      isLoadingWait = true;
    }
    scrollAnimationFrame = requestAnimationFrame(() => scrollLoop(container, pixelsPerFrame));
    return;
  }
  isLoadingWait = false;

  container.scrollBy({ top: -pixelsPerFrame, behavior: 'auto' });

  if (frameCount % SAMPLE_INTERVAL === 0) {
    let currentScrollTop = container.scrollTop;
    let currentDOMHash = getDOMStateHash(container);

    if (frameCount > WARMUP_FRAMES) {
      if (currentDOMHash === "DEAD_END") {
        printLog("命中到顶 DOM 特征标志，自动停止。");
        stopCapture();
        return;
      }
      const isPositionUnchanged = (currentScrollTop === lastCheckPosition);
      const isDOMUnchanged = (currentDOMHash === lastDOMStateHash);
      if (isPositionUnchanged || isDOMUnchanged) {
        unchangedCount++;
        if (unchangedCount >= MAX_UNCHANGED_STRIKES) {
          printLog("经复合判定：已到最顶端，自动停止。");
          stopCapture();
          return;
        }
      } else {
        unchangedCount = 0;
      }
    }
    lastCheckPosition = currentScrollTop;
    lastDOMStateHash = currentDOMHash;
  }

  scrollAnimationFrame = requestAnimationFrame(() => scrollLoop(container, pixelsPerFrame));
}

async function startCapture(speedMode) {
  try {
    const container = findTrueScrollContainer();

    // 先沉底
    container.scrollTop = container.scrollHeight;
    await new Promise(resolve => setTimeout(resolve, 300));
    printLog("已完成初始沉底，开始获取屏幕流...");

    let selectedMimeType = 'video/webm; codecs=vp9';
    if (!MediaRecorder.isTypeSupported(selectedMimeType)) {
      selectedMimeType = 'video/webm; codecs=vp8';
      if (!MediaRecorder.isTypeSupported(selectedMimeType)) selectedMimeType = 'video/webm';
    }

    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: { width: 1280, height: 720, frameRate: 15 },
      audio: false
    });

    mediaRecorder = new MediaRecorder(stream, { mimeType: selectedMimeType });
    recordedChunks = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };
    mediaRecorder.onstop = sendVideoToBackground;
    mediaRecorder.start();

    let pixelsPerFrame = 4;
    if (speedMode === "slow") pixelsPerFrame = 1.5;
    if (speedMode === "fast") pixelsPerFrame = 9;

    isScrolling = true;
    frameCount = 0;
    unchangedCount = 0;
    isLoadingWait = false;
    lastCheckPosition = container.scrollTop;
    lastDOMStateHash = getDOMStateHash(container);

    scrollLoop(container, pixelsPerFrame);
  } catch (err) {
    console.error("录制初始化中断/失败:", err);
  }
}

function stopCapture() {
  isScrolling = false;
  if (scrollAnimationFrame) cancelAnimationFrame(scrollAnimationFrame);
  if (mediaRecorder && mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
    mediaRecorder.stream.getTracks().forEach(track => track.stop());
  }
}

function sendVideoToBackground() {
  if (recordedChunks.length === 0) return;
  const blob = new Blob(recordedChunks, { type: 'video/webm' });
  const reader = new FileReader();
  reader.onloadend = function () {
    chrome.runtime.sendMessage({
      action: "DOWNLOAD_VIDEO_DATA",
      dataUrl: reader.result
    });
  };
  reader.readAsDataURL(blob);
}

function printLog(msg) {
  console.log(`[Recorder] ${msg}`);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START") startCapture(request.speedMode);
  else if (request.action === "STOP") stopCapture();
});
