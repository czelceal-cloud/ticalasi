chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "DOWNLOAD_VIDEO_DATA") {
    chrome.downloads.download({
      url: request.dataUrl,
      filename: `chat-record-${Date.now()}.webm`,
      saveAs: true
    });
  }
});
